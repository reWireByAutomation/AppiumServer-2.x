import self
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

appium_server_url = 'http://127.0.0.1:4723'
driver = None


class AndroidAutomationReadinessTest():

    @staticmethod
    def appium_test(self):
        options = UiAutomator2Options()
        options.platform_name = "Android"
        options.platform_version = "14"
        options.app_package = "io.appium.android.apis"
        options.app_activity = "io.appium.android.apis.ApiDemos"
        options.automation_name = "UiAutomator2"
        options.device_name = "emulator-5554"
        options.udid = "emulator-5554"

        self.driver = webdriver.Remote(appium_server_url, options=options)
        val = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, value="App")
        print("App Text : ", val.text)
        print("Get App Element text attribute value : ",val.get_attribute("text"))
        val.click()
        val = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, value="Alarm")
        print("Get Text Value of Alaram Element :", val.text)
        val.click()
        self.driver.back()
        self.driver.back()
        self.driver.quit()


AndroidAutomationReadinessTest.appium_test(self)
