package org.appium.automation.appiumApiDemoApp.uiScrollable;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;

public class ScrollToEndToBegin {

    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        //Set UiAutomator2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");

        //Declare and Initialize Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

        //Navigation To App
        WebElement element = driver.findElement(AppiumBy.accessibilityId("App"));
        element.click();

        //Navigation To Activity
        element = driver.findElement(AppiumBy.accessibilityId("Activity"));
        element.click();

        //scrollToEnd(int maxswipes) - Working
        //####################
        driver.findElement(new AppiumBy.ByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollToEnd(3)"));
        //####################

        element = driver.findElement(AppiumBy.accessibilityId("Wallpaper"));
        System.out.println("Last Element Text:" + element.getText());
        Thread.sleep(2000);

        //Scroll to Beginning
        driver.findElement(new AppiumBy.ByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollToBeginning(3)"));
        element = driver.findElement(AppiumBy.accessibilityId("Animation"));
        System.out.println("First Element Text:" + element.getText());

        driver.quit();

    }



}
