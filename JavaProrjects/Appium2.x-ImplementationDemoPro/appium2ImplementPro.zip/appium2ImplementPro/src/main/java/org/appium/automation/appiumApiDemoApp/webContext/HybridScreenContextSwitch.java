package org.appium.automation.appiumApiDemoApp.webContext;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.remote.SupportsContextSwitching;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Set;

public class HybridScreenContextSwitch {


    public static void main(String[] args) throws MalformedURLException, InterruptedException {


        //Set UiAutomator2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        //Declare and Derive Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
        //Navigate to Views
        WebElement element = driver.findElement(AppiumBy.accessibilityId("Views"));
        System.out.println(element.getText());
        element.click();

        //Scroll to an element and Select WebView Element
        driver.findElement(new AppiumBy.ByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(textMatches(\"WebView\").instance(0));"));
        element = driver.findElement(AppiumBy.accessibilityId("WebView"));
        System.out.println(element.getText());
        element.click();

        //Getting Context Names

        Set<String> contextNames = ((SupportsContextSwitching) driver).getContextHandles();
        for (String contextName : contextNames) {
            System.out.println(contextName); //prints out something like NATIVE_APP \n WEBVIEW_1
        }

        //Set & Switch to Web
        ((SupportsContextSwitching) driver).context("WEBVIEW_io.appium.android.apis");

        String val = driver.findElement(By.linkText("i am a link")).getText(); //working
        System.out.println("Link Text:" + val);

        WebElement txtBoxElement = driver.findElement(By.id("i_am_a_textbox"));
        System.out.println("Default value of Text Box: " + txtBoxElement.getAttribute("name"));
        txtBoxElement.clear();
        txtBoxElement.sendKeys("This is Hybrid App Entry");
        Thread.sleep(2000);

        //Switching back to Native
        ((SupportsContextSwitching) driver).context("NATIVE_APP");
        driver.navigate().back();
        //Below is Native App Operation Starts Again

        // WebView Element Text is displayed
        element = driver.findElement(AppiumBy.accessibilityId("Visibility"));
        System.out.println(element.getText());

        driver.navigate().back();

        driver.quit();

    }





}
