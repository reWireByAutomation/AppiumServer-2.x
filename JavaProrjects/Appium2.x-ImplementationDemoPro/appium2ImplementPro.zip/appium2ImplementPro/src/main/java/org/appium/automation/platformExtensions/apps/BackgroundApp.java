package org.appium.automation.platformExtensions.apps;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class BackgroundApp {


    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

        //putting app into background for 5 seconds and will reactivate automatically
        driver.executeScript("mobile: backgroundApp", ImmutableMap.of(
                "seconds", 5
        ));

        //querying app state , it should be in the foreground as previous background mode is completed
        long appState = (long) driver.executeScript("mobile: queryAppState", ImmutableMap.of(
                "appId", "io.appium.android.apis"
        ));
        //Expected Value is 4 , should be in foreground
        System.out.println("App State - Api Demo: " + appState);

        //completely putting app into background mode, any negative value will remains app into background
        driver.executeScript("mobile: backgroundApp", ImmutableMap.of(
                "seconds", -1
        ));

        appState = (long) driver.executeScript("mobile: queryAppState", ImmutableMap.of(
                "appId", "io.appium.android.apis"
        ));
        //Expected value is 3 , should be in background
        System.out.println("App State - Api Demo: " + appState);

        driver.quit();

    }





}
