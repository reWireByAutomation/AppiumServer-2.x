package org.appium.automation.appiumApiDemoApp.uiScrollable;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;

public class ScrollTextIntoViewSpec {

    public static void main(String[] args) throws MalformedURLException, InterruptedException {


        //Set UiAutomator2 Options

        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");

        //Declare and Initialize Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

        //Navigate to Views
        WebElement element = driver.findElement(AppiumBy.accessibilityId("Views"));
        element.click();

        //Scroll Until WebView3 Text
        //###################
        driver.findElement(new AppiumBy.ByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollTextIntoView(\"WebView3\")"));
        //####################
        System.out.println("End Element Text:" + driver.findElement(AppiumBy.accessibilityId("WebView3")).getText());

        //Scroll Until Animation UiSelector
        driver.findElement(new AppiumBy.ByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollTextIntoView(\"Animation\")"));
        System.out.println("Beginning Element Text:" + driver.findElement(AppiumBy.accessibilityId("Animation")).getText());

        driver.quit();

    }








}
