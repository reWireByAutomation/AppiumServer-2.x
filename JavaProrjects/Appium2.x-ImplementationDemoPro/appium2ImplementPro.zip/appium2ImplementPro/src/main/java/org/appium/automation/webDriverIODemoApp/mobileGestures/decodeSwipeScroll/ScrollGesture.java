package org.appium.automation.webDriverIODemoApp.mobileGestures.decodeSwipeScroll;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class ScrollGesture {


    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        //Define UiAutomator2 Options

        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("com.wdiodemoapp");
        options.setAppActivity("com.wdiodemoapp.MainActivity");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        //Declare and Define Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
        driver.findElement(AppiumBy.accessibilityId("Swipe")).click();

        //Define Element
        WebElement elementCard = driver.findElement(AppiumBy.xpath("(//android.view.ViewGroup[@content-desc=\"card\"])[1]"));

        //Scroll Up - Frist Time
        ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) elementCard).getId(),
                "direction", "up",
                "percent", 1.0,
                "speed", 500
        ));

        //Second time scroll up - Second Time
        ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) elementCard).getId(),
                "direction", "up",
                "percent", 1.0,
                "speed", 500
        ));

        //thrid time scroll up - Third Time
        ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) elementCard).getId(),
                "direction", "up",
                "percent", 1.0,
                "speed", 500
        ));


        //Scroll Down
        WebElement elementLogo = driver.findElement(AppiumBy.accessibilityId("WebdriverIO logo"));

        //Scroll Down - Fist Time
        ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) elementLogo).getId(),
                "direction", "down",
                "percent", 1.0,
                "speed", 500
        ));

        //Scroll Down - Second Time
        ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) elementCard).getId(),
                "direction", "down",
                "percent", 1.0,
                "speed", 500
        ));

        //Scroll Down - Third Time
        ((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) elementCard).getId(),
                "direction", "down",
                "percent", 1.0,
                "speed", 500
        ));

        driver.findElement(AppiumBy.accessibilityId("Home")).click();
        driver.quit();
    }



}
