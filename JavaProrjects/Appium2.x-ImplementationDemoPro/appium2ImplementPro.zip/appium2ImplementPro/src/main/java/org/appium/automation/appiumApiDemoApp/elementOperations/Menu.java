package org.appium.automation.appiumApiDemoApp.elementOperations;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class Menu {


//########################################################
// Scenario Details:
// Scenario Name: Get Dropdown Menu Item
// Navigation:
// App > Menu > Inflate fm XML Element > Dropdown Menu
// Get The Dropdown Menu Elements
// Get Text Value of Dropdown Menu Element
// Simulate Actions on Desired Menu Element
//########################################################

 public static void main(String[] args) throws MalformedURLException {


     List<WebElement> menuElements = null;

     //Define UiAutomator2 Options

     UiAutomator2Options options = new UiAutomator2Options();
     options.setAutomationName("UiAutomator2");
     options.setUdid("emulator-5554");
     options.setAppPackage("io.appium.android.apis");
     options.setAppActivity("io.appium.android.apis.ApiDemos");
     options.setPlatformName("Android");
     options.setPlatformVersion("14");


     //Declare & Initialize Driver
     AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"),options);

     //Choose Selector , Define and simulate action on the element
     driver.findElement(AppiumBy.accessibilityId("App")).click();
     driver.findElement(AppiumBy.accessibilityId("Menu")).click();

     //Click on Inflate fm XML Element
     driver.findElement(AppiumBy.id("android:id/text1")).click();
     //Click on Down Arrow
     driver.findElement(AppiumBy.id("io.appium.android.apis:id/spinner")).click();

     //Get All Menu Elements
     menuElements = driver.findElements(AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.CheckedTextView\")"));

     System.out.println("Menu List Items Count:" + menuElements.size());

     for (WebElement menuElement : menuElements){

         System.out.println(menuElement.getText());

         if (menuElement.getText().equalsIgnoreCase("Disabled")){

             //Click on Disable Menu Element
             menuElement.click();

             //Back to Home Page
             driver.navigate().back();
             driver.navigate().back();
             driver.navigate().back();
             driver.navigate().back();
         }
     }
     driver.quit();

 }


}
