package org.appium.automation.appiumApiDemoApp.elementOperations;


//########################################################
// Scenario Details:
// Scenario Name: Enter Data in the Edit boxes
// Navigation: App > Alert Dialogs > Text Entry Dialogs
// Simulate Operations to enter values in the Edit Boxes
//########################################################

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;

public class TextEntry {


    public static void main(String[] args) throws MalformedURLException {

        //Define UiAutomator2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");

        //Declare & Initialize Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"),options);

        //Choose Selector , Define and simulate action on the element
        driver.findElement(AppiumBy.accessibilityId("App")).click();
        driver.findElement(AppiumBy.accessibilityId("Alert Dialogs")).click();
        driver.findElement(AppiumBy.accessibilityId("Text Entry dialog")).click();

        //Choose Selector and Define Element - User Name
        WebElement userNameElement = driver.findElement(AppiumBy.xpath("//android.widget.EditText[contains(@resource-id,'username_edit')]"));

        //Simulate Text entry action on the element
        userNameElement.sendKeys("Test1");
        System.out.println("Entered UserName: " + userNameElement.getText());

        //Simulate Text entry action on the element
        WebElement passwordElement = driver.findElement(AppiumBy.xpath("//android.widget.EditText[contains(@resource-id,'password_edit')]"));
        passwordElement.sendKeys("Password123");
        System.out.println("Entered Password: " + passwordElement.getText());

        //Click on OK Button
        driver.findElement(AppiumBy.id("android:id/button1")).click();
        driver.navigate().back();
        driver.quit();


    }



}
