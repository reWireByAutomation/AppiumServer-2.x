package org.appium.automation.platformExtensions.apps;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class GetActivityAndPackageName {


    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

        driver.findElement(AppiumBy.accessibilityId("App")).click();
        driver.findElement(AppiumBy.accessibilityId("Alert Dialogs")).click();

        //Get Current Activity of the Screen
        String cActivity = (String) driver.executeScript("mobile: getCurrentActivity");
        System.out.println("Current Activity Name of the Screen: " + cActivity);

        //Get Package Name of the App
        String cPackageName = (String) driver.executeScript("mobile: getCurrentPackage");
        System.out.println("Current Package Name of the App: " + cPackageName);

        driver.quit();

    }





}
