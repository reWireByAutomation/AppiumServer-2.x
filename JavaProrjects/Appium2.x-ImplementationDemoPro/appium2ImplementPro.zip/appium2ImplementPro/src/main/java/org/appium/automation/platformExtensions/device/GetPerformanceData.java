package org.appium.automation.platformExtensions.device;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class GetPerformanceData {


    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        //Set UiAutomator2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        //Declare and Derive driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);


        //batteryinfo or cpuinfo or memoryinfo or networkinfo

        var data = driver.executeScript("mobile: getPerformanceData", ImmutableMap.of(
                "packageName", "io.appium.android.apis",
                "dataType", "batteryinfo"
        ));
        System.out.println("battery info: " + data.toString());

//        data = driver.executeScript("mobile: getPerformanceData", ImmutableMap.of(
//                "packageName", "io.appium.android.apis",
//                "dataType", "cpuinfo"
//        ));
        //System.out.println("cpu info: " + data.toString());

        data = driver.executeScript("mobile: getPerformanceData", ImmutableMap.of(
                "packageName", "io.appium.android.apis",
                "dataType", "memoryinfo"
        ));
        System.out.println("memory info: " + data.toString());

        data = driver.executeScript("mobile: getPerformanceData", ImmutableMap.of(
                "packageName", "io.appium.android.apis",
                "dataType", "networkinfo"
        ));
        System.out.println("network info: " + data.toString());

        driver.quit();

    }





}
