package org.appium.automation.appiumApiDemoApp.elementOperations;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class RadioButtons {

//########################################################
// Scenario Details:
// Scenario Name: Select Radio Button
// Navigation:
// App > Menu > Alert Dialogs > Single Chose List
// Steps:
// Define Selector Strategy for Radio Buttons
// Iterate list of Radio Buttons
// Get The Radio Buttons text value
// Get the Checked and Enabled Status value of Radio Buttons
// Select Street View Radio Button
// Navigate back to screen
// Driver Session Ends
//########################################################

public static void main(String[] args) throws MalformedURLException {


    List<WebElement> radioButtonElements = null;

    //Define UiAutomator2 Options

    UiAutomator2Options options = new UiAutomator2Options();
    options.setAutomationName("UiAutomator2");
    options.setUdid("emulator-5554");
    options.setAppPackage("io.appium.android.apis");
    options.setAppActivity("io.appium.android.apis.ApiDemos");
    options.setPlatformName("Android");
    options.setPlatformVersion("14");

    //Declare & Initialize Driver
    AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"),options);

    //Choose Selector , Define and simulate action on the element
    driver.findElement(AppiumBy.accessibilityId("App")).click();
    driver.findElement(AppiumBy.accessibilityId("Alert Dialogs")).click();
    driver.findElement(AppiumBy.accessibilityId("Single choice list")).click();

    //Radio Buttons by resource-ic Strategy
    radioButtonElements = driver.findElements(AppiumBy.xpath("//android.widget.CheckedTextView[contains(@resource-id,'text1')]"));

    //Iterate Radio buttons
    for (WebElement radioButtonElement : radioButtonElements){
        System.out.println("Text Value: " + radioButtonElement.getText());

        System.out.println("Check Status: " + radioButtonElement.getAttribute("checked"));
        System.out.println("Enable Status: " + radioButtonElement.getAttribute("enabled"));

        //Select Street View Radio button
        if (radioButtonElement.getText().equalsIgnoreCase("Street view")){

            radioButtonElement.click();
            System.out.println("Check Status: " + radioButtonElement.getAttribute("checked"));

            //click on OK button
            driver.findElement(AppiumBy.id("android:id/button1")).click();
        }
        System.out.println("#############################");
    }
    driver.navigate().back();
    driver.quit();



}





}
