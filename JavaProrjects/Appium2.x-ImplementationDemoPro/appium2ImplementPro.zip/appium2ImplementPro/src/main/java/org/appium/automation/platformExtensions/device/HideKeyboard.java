package org.appium.automation.platformExtensions.device;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class HideKeyboard {


    public static void main(String[] args) throws MalformedURLException, InterruptedException {


        //Set UiAutomator2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        //Declare and Derive Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

        //Navigate to App > Search > Invoke Search
        driver.findElement(AppiumBy.accessibilityId("App")).click();
        driver.findElement(AppiumBy.accessibilityId("Search")).click();
        driver.findElement(AppiumBy.accessibilityId("Invoke Search")).click();
        driver.findElement(AppiumBy.id("io.appium.android.apis:id/txt_query_prefill")).click();
        Thread.sleep(2000);

        //Validate IsKeyboard Shown
        //return true if visible

        Boolean isKBShown = (Boolean) driver.executeScript("mobile: isKeyboardShown");
        System.out.println("Keyboard Shown Status: " + isKBShown);

        //Hide Keyboard is successfully hidden , value true is returned
        //false , if it was already invisible
        //throws an exception if keyboard unable to hide
        Boolean isKBHidden = (Boolean) driver.executeScript("mobile: hideKeyboard");
        System.out.println("Keyboard Hide Status: " + isKBHidden);

        driver.quit();

    }



}
