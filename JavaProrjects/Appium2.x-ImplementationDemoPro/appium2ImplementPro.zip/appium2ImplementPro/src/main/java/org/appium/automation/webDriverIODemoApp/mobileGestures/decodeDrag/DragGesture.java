package org.appium.automation.webDriverIODemoApp.mobileGestures.decodeDrag;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class DragGesture {


    public static void main(String[] args) throws MalformedURLException {


        //Define UiAutomatior2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("com.wdiodemoapp");
        options.setAppActivity("com.wdiodemoapp.MainActivity");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        //Declare and Define Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

        driver.findElement(AppiumBy.accessibilityId("Drag")).click();

        WebElement sourceElement = driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"drag-c1\"]"));
        if (sourceElement.isDisplayed()){
            System.out.println("Drag Element C1 is available");
        }else{
            System.out.println("Drag Element C1 is not available");
        }

//        WebElement targetElement = driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"drop-c1\"]"));
//        if (targetElement.isDisplayed()){
//            System.out.println("Drop Element C1 is available");
//        }else{
//            System.out.println("Drop Element C1 is not available");
//        }
//
        ((JavascriptExecutor) driver).executeScript("mobile: dragGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) sourceElement).getId(),
                "endX", 100,
                "endY", 100
        ));

        driver.findElement(AppiumBy.accessibilityId("Home")).click();
        driver.quit();
    }





}
