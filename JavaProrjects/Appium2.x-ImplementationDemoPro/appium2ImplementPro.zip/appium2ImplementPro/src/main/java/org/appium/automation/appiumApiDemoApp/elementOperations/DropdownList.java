package org.appium.automation.appiumApiDemoApp.elementOperations;


//########################################################
// Scenario Details:
// Scenario Name: Get Dropdown List
// Navigation:
// App > Alert Dialogs > List Dialog
// Get The Dropdown list Elements
// Get Text Value of Dropdown list item
// Assert Dropdown list item
//########################################################

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class DropdownList {

 public static void main(String[] args) throws MalformedURLException {

     List<WebElement> dropDownElements = null;


     //Define UiAutomator2 Options

     UiAutomator2Options options = new UiAutomator2Options();
     options.setAutomationName("UiAutomator2");
     options.setUdid("emulator-5554");
     options.setAppPackage("io.appium.android.apis");
     options.setAppActivity("io.appium.android.apis.ApiDemos");
     options.setPlatformName("Android");
     options.setPlatformVersion("14");

     //Declare & Initialize Driver
     AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"),options);

     driver.findElement(AppiumBy.accessibilityId("App")).click();
     driver.findElement(AppiumBy.accessibilityId("Alert Dialogs")).click();
     driver.findElement(AppiumBy.accessibilityId("List dialog")).click();

     //By Xpath with resource-id <Manage Strategy>
     dropDownElements = driver.findElements(AppiumBy.xpath("//android.widget.TextView[contains(@resource-id,'text1')]"));

     //Get Drop list items
     for (WebElement listElement : dropDownElements){

         System.out.println(listElement.getText());

         if (listElement.getText().contains("four")){
             listElement.click();
             String text = driver.findElement(AppiumBy.id("android:id/message")).getText();
             //Assert Dropdown list item
             if (text.contains("Command four")) {
                 System.out.println("Passed");
             } else {
                 System.out.println("Failed");
             }
         }
     }
     driver.navigate().back();
     driver.quit();


 }


}
