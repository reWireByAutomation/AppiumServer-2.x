package org.appium.automation.platformExtensions.device;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class GetDeviceInformation {


    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        //Set UiAutomator2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity("io.appium.android.apis.ApiDemos");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        //Declare and Derive Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);

        //Get the Device information
        var deviceInfo = driver.executeScript("mobile: deviceInfo");
        String infoAll = deviceInfo.toString();

        System.out.println("$$$$$$$$$$$$$ Entire String Display $$$$$$$$$$$$$$$$$$$$$$");
        System.out.println(infoAll);
        System.out.println("$$$$$$$$$$$$$$$$$$$ String Display ends $$$$$$$$$$$$$$$$$$$$$$");

        System.out.println("################################");

        //Dividing string based on ","
        String[] parts = infoAll.split(",");

        //Loop through string array
        for (String part : parts) {
            System.out.println(part.trim());
        }

        driver.quit();

    }




}
