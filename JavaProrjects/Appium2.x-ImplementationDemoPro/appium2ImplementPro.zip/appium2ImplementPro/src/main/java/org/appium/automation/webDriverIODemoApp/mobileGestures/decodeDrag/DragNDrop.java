package org.appium.automation.webDriverIODemoApp.mobileGestures.decodeDrag;

import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class DragNDrop {

    public static void main(String[] args) throws MalformedURLException, InterruptedException {

        //Set UiAutomator2 Options
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAutomationName("UiAutomator2");
        options.setUdid("emulator-5554");
        options.setAppPackage("com.wdiodemoapp");
        options.setAppActivity("com.wdiodemoapp.MainActivity");
        options.setPlatformName("Android");
        options.setPlatformVersion("14");
        options.setNoReset(false);
        options.setFullReset(false);
        options.setNewCommandTimeout(Duration.ofSeconds(500));
        options.setPrintPageSourceOnFindFailure(true);

        //Declare and Define Driver
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
        //Tap on Drag Element
        driver.findElement(AppiumBy.accessibilityId("Drag")).click();

        //Define Source Element for Drag
        WebElement sourceElement = driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"drag-c1\"]"));
        if (sourceElement.isDisplayed()){
            System.out.println("Drag Element C1 is available");
        }else{
            System.out.println("Drag Element C1 is not available");
        }
        //Define Target Element for Drop
        WebElement targetElement = driver.findElement(AppiumBy.xpath("//android.view.ViewGroup[@content-desc=\"drop-c1\"]"));
        if (targetElement.isDisplayed()){
            System.out.println("Drop Element C1 is available");
        }else{
            System.out.println("Drop Element C1 is not available");
        }

        //Get X,Y Coordinates of Source Element
        //Point sourceLocation = sourceElement.getLocation();
        //Get Width and Height of Source Element
        // Dimension sourceSize = sourceElement.getSize();
        //Get Center of the Source Element
        //Point sourceElementCenter = new Point(sourceLocation.x + sourceSize.getWidth()/2,sourceLocation.y + sourceSize.getHeight()/2);

        //Get X,Y Coordinates of Target Element
        Point targetLocation = targetElement.getLocation();
        System.out.println("Targetlocation of X: " + targetLocation.x);
        System.out.println("Targetlocation of Y: " + targetLocation.y);

        //Get Width and Height of Target Element
        Dimension targetSize = targetElement.getSize();
        System.out.println("TargetElement Width: " + targetSize.getWidth());
        System.out.println("TargetElement Height: " + targetSize.getHeight());

        //Get Center of the Target Element
        Point targetElementCenter = new Point(targetLocation.x + targetSize.getWidth()/2,targetLocation.y + targetSize.getHeight()/2);

        System.out.println("TargetElementCenter X: " + targetElementCenter.x);
        System.out.println("TargetElementCenter Y: " + targetElementCenter.y);

        ((JavascriptExecutor) driver).executeScript("mobile: dragGesture", ImmutableMap.of(
                "elementId", ((RemoteWebElement) sourceElement).getId(),
                "endX", targetElementCenter.x,
                "endY", targetElementCenter.y
        ));

        Thread.sleep(2000);

        driver.findElement(AppiumBy.accessibilityId("Home")).click();
        driver.quit();
    }




}
